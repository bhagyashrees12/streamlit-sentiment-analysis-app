// Navbar
const menu = document.querySelector('.menu');
const navbar = document.querySelector('.navbar');

menu.addEventListener('click', () => {
    navbar.classList.toggle('change');
    menu.classList.toggle('change');
});


// End of Navbar 

// Section 2 Video
const video = document.querySelector('.video')
const btn = document.querySelector('.buttons i')
const bar = document.querySelector('.video-bar')

const playPause = () => {
    if (video.paused) {
        video.play()
        btn.className = 'far fa-pause-circle'
        video.style.opacity = '.7'
    } else {
        video.pause()
        btn.className = 'far fa-play-circle'
        video.style.opacity = '.3'
    }
}

btn.addEventListener('click', () => {
    playPause()
})

video.addEventListener('timeupdate', () => {
    const barWidth = video.currentTime / video.duration
    bar.style.width = `${barWidth * 100}%`
    if (video.ended) {
        btn.className = 'far fa-play-circle'
        video.style.opacity = '.3'
    }
})
// End of Section 2 Video

// Section 3 Pricing Cards
// Your portfolio JavaScript code goes here

const stars = document.querySelectorAll('#feedback .star');
const commentInput = document.getElementById('comment-input');
const submitBtn = document.getElementById('submit-btn');

let rating = 0;

stars.forEach((star, index) => {
    star.addEventListener('click', () => {
        resetStars();
        rating = index + 1;
        setStarsRating(rating);
    });

    star.addEventListener('mouseover', () => {
        resetStars();
        setStarsRating(index + 1);
    });

    star.addEventListener('mouseout', () => {
        setStarsRating(rating);
    });
});

function resetStars() {
    stars.forEach(star => star.classList.remove('active'));
}

function setStarsRating(numStars) {
    stars.forEach((star, index) => {
        if (index < numStars) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });
}

submitBtn.addEventListener('click', () => {
    const comment = commentInput.value.trim();
    if (rating === 0 && comment === '') {
        alert('Please provide a rating or a comment.');
    } else {
        const feedback = {
            rating,
            comment
        };
        // Here, you can send the feedback data to a server or do something else with it
        console.log(feedback);
        alert('Thank you for your feedback!');
    }
});
// End of Section 3 Pricing Cards

// Add this code at the end of your script.js file
const navLinks = document.querySelectorAll('.nav-link');

navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = e.target.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        targetElement.scrollIntoView({ behavior: 'smooth' });
        if (navbar.classList.contains('change')) {
            navbar.classList.remove('change');
            menu.classList.remove('change');
        }
    });
});